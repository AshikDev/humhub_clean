<?php
return array (
  'New message in discussion from %displayName%' => 'Jauna ziņa diskusijā no %displayName%',
);
