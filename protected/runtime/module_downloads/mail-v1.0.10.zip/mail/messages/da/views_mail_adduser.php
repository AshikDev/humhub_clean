<?php

return [
    'Add more participants to your conversation...' => 'Tilføj flere deltagere til din samtale...',
];
