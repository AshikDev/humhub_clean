<?php

return [
    'Add recipients' => 'Lisää vastaanottajia',
    'New message' => 'Uusi viesti',
    'Send' => 'Lähetä',
];
