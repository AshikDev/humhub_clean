<?php
return array (
  'Message' => 'Melding',
);
