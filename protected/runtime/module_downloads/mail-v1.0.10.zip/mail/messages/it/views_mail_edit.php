<?php

return [
    'Edit message entry' => 'Modifica messaggio',
];
