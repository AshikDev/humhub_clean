<?php
return array (
  'New message from {senderName}' => 'رسالة جديدة من {senderName}',
  'and {counter} other users' => 'و عدد {counter} مستخدم',
);
