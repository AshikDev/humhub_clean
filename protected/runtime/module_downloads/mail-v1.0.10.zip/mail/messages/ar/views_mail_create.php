<?php

return [
    'Add recipients' => '',
    'New message' => 'رسالة جديدة',
    'Send' => 'ارسال',
];
