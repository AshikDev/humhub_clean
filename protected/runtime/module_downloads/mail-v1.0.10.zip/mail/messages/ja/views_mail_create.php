<?php

return [
    'Add recipients' => '宛先を追加',
    'New message' => '新しいメッセージ',
    'Send' => '送信',
];
