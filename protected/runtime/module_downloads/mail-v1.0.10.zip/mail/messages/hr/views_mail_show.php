<?php

return [
    'Delete conversation' => '',
    'Leave conversation' => '',
    '<strong>Confirm</strong> deleting conversation' => '<strong>Potvrdi</strong> brisanje razgovora',
    '<strong>Confirm</strong> leaving conversation' => '<strong>Potvrdi</strong> napuštanje razgovora',
    '<strong>Confirm</strong> message deletion' => '<strong>Potvrdi</strong> brisanje poruke',
    'Add user' => 'Dodaj korisnika',
    'Cancel' => 'Poništi',
    'Delete' => 'Obriši',
    'Do you really want to delete this conversation?' => 'Zaista želite obrisati ovaj razgovor?',
    'Do you really want to delete this message?' => 'Zaista želite obrisati ovu poruku?',
    'Do you really want to leave this conversation?' => 'Zaista želite napustiti ovaj razgovor?',
    'Leave' => 'Napusti',
    'Send' => 'Pošalji',
    'There are no messages yet.' => 'Još nema poruka.',
];
