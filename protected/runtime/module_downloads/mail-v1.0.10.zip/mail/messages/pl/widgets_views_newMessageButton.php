<?php
return array (
  'New message' => 'Nowa wiadomość ',
  'Send message' => 'Wyślij wiadomość',
);
