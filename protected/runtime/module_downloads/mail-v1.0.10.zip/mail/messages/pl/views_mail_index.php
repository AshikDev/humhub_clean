<?php
return array (
  'Conversations' => 'Rozmowy',
  'New' => 'Nowa',
  'There are no messages yet.' => 'Nie ma jeszcze wiadomości.',
);
