<?php
return array (
  'Sign up now' => 'Dona\'t d\'alta ara',
);
