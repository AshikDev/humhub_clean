<?php

return [
    '<strong>Confirm</strong> deleting conversation' => '',
    '<strong>Confirm</strong> leaving conversation' => '',
    '<strong>Confirm</strong> message deletion' => '',
    'Delete conversation' => '',
    'Do you really want to delete this conversation?' => '',
    'Do you really want to delete this message?' => '',
    'Do you really want to leave this conversation?' => '',
    'Leave' => '',
    'Leave conversation' => '',
    'Add user' => 'Afegeix membres',
    'Cancel' => 'Cancel·la',
    'Delete' => 'Suprimeix',
    'Send' => 'Envia',
    'There are no messages yet.' => 'No tens cap missatge.',
];
