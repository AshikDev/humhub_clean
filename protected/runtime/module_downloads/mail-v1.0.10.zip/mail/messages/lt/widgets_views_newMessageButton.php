<?php
return array (
  'New message' => 'Nauja žinutė',
  'Send message' => 'Siųsti žinutę',
);
