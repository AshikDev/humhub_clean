<?php

return [
    'Conversations' => 'Conversaciones',
    'New' => 'Nuevo',
    'There are no messages yet.' => 'No hay mensajes aún.',
];
