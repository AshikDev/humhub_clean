<?php
return array (
  'Messages' => 'Mensajes',
  'New message' => 'Nuevo mensaje',
  'Show all messages' => 'Mostrar todos los mensajes',
);
