<?php
return array (
  'Message' => 'Pesan',
  'Recipient' => '',
  'Subject' => '',
  'You cannot send a email to yourself!' => '',
);
