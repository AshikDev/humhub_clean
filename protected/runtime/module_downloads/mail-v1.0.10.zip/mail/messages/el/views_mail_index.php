<?php

return [
    'Conversations' => '',
    'There are no messages yet.' => '',
    'New' => 'Νέα',
];
