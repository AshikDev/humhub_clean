<?php
return array (
  'Groups' => 'Ομάδες',
  'Members' => 'Μέλη',
  'Spaces' => '',
  'User Posts' => '',
);
