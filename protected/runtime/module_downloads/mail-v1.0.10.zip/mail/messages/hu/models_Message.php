<?php
return array (
  'New message from {senderName}' => '{senderName} új üzenetet küldött',
  'and {counter} other users' => 'és {counter} további felhasználó',
);
