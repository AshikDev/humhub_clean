<?php

return [
    'New message from {senderName}' => '',
    'and {counter} other users' => '',
];
