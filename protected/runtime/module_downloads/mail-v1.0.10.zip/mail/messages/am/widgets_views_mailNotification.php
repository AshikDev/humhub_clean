<?php

return [
    'Messages' => '',
    'New message' => '',
    'Show all messages' => '',
];
