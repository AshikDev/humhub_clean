<?php

return [
    'New message in discussion from %displayName%' => '',
];
