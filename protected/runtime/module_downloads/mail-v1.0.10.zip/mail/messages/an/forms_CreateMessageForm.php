<?php
return array (
  'Message' => 'Mensache',
  'Recipient' => 'Destinatario',
  'Subject' => 'Asunto',
  'You cannot send a email to yourself!' => '',
);
