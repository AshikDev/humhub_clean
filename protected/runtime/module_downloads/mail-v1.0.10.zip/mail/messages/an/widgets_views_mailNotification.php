<?php
return array (
  'Messages' => 'Mensaches',
  'New message' => 'Nuevo mensache',
  'Show all messages' => 'Veyer totz os mensaches',
);
