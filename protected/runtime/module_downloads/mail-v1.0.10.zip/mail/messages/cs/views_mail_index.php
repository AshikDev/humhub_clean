<?php

return [
    'Conversations' => 'Konverzace',
    'New' => 'Nová',
    'There are no messages yet.' => 'Zatím zde nejsou žádné zprávy.',
];
