<?php
return array (
  'Groups' => 'Skupiny',
  'Members' => 'Členové',
  'Spaces' => 'Prostory',
  'User Posts' => 'Příspěvky uživatelů',
);
