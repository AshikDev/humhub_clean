<?php
return array (
  'Members' => 'Μέλη',
  'Owner' => '',
  'Pending Approvals' => '',
  'Pending Invites' => '',
);
