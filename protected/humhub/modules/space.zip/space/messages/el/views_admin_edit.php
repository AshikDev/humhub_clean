<?php
return array (
  'Archive' => '',
  'Choose if new content should be public or private by default' => '',
  'Choose the kind of membership you want to provide for this workspace.' => '',
  'Choose the security level for this workspace to define the visibleness.' => '',
  'Delete' => 'Διαγραφή',
  'Save' => 'Αποθήκευση',
  'Unarchive' => '',
);
