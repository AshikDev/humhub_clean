<?php
return array (
  'Your password' => 'Ο κωδικός σου',
);
