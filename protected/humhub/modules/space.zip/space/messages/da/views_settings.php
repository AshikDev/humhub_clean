<?php
return array (
  '<strong>Security</strong> settings' => '<strong>Sikkerheds</strong> indstillinger',
  '<strong>Space</strong> settings' => '',
  'Permissions are assigned to different user-roles. To edit a permission, select the user-role you want to edit and change the drop-down value of the given permission.' => '',
);
