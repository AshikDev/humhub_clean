<?php
return array (
  'Close' => 'Luk',
  'Request workspace membership' => 'Anmod om workspace medlemskab',
  'Your request was successfully submitted to the workspace administrators.' => 'Din anmodning blev med succes afsendt til workspace administratorerne.',
);
