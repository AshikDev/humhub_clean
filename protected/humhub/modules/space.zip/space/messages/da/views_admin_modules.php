<?php
return array (
  '<strong>Space</strong> Modules' => '<strong>Side</strong> Moduler',
  'Activated' => 'Aktiveret',
  'Are you sure? *ALL* module data for this space will be deleted!' => 'Er du sikker? *ALLE* modul data for denne side vil blive slettet!',
  'Configure' => 'Konfigurer',
  'Currently there are no modules available for this space!' => 'Der er på nuværende tidspunkt ingen tilgængelige moduler til denne side!',
  'Disable' => 'Deaktiver',
  'Enable' => 'Aktiver',
  'Enhance this space with modules.' => 'Udvid denne side med moduler.',
);
