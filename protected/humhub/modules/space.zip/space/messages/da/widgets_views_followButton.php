<?php
return array (
  'Follow' => 'Følg ',
  'Unfollow' => 'Følg ikke længere',
);
