<?php
return array (
  'Send & decline' => 'Send & afslå',
);
