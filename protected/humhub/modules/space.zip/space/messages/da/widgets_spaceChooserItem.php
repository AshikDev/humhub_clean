<?php
return array (
  'This space is archived' => '',
  'You are a member of this space' => 'Du er medlem af denne side',
  'You are following this space' => '',
);
