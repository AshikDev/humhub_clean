<?php
return array (
  'Change image' => 'Skift billede',
  'Current space image' => 'Nuværende side billede',
);
