<?php
return array (
  'Archive' => 'Arkiv',
  'Choose if new content should be public or private by default' => 'Vælg om nyt indhold som standard skal være offentlig eller privat',
  'Choose the kind of membership you want to provide for this workspace.' => 'Vælg den type af medlemskab som du vil give til dette workspace.',
  'Choose the security level for this workspace to define the visibleness.' => 'Vælg sikkerhedsgraden for dette workspace for at definere synlighed.',
  'Delete' => 'Slet',
  'Save' => 'Gem',
  'Unarchive' => 'U-arkivér',
);
