<?php
return array (
  '<strong>New</strong> member request' => '<strong>Ny</strong> medlems anmodning',
  '<strong>Space</strong> members' => '<strong>Side</strong> medlemmer',
  'Show all' => 'Vis alle',
);
