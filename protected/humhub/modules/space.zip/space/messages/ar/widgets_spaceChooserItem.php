<?php
return array (
  'This space is archived' => '',
  'You are a member of this space' => 'انت عضو في هذه الباحة',
  'You are following this space' => '',
);
