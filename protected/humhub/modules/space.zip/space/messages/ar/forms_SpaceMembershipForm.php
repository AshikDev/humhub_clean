<?php
return array (
  'Application message' => '',
);
