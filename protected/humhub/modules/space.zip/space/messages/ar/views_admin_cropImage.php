<?php
return array (
  '<strong>Modify</strong> space image' => '',
  'Close' => 'اغلاق',
);
