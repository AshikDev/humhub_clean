<?php
return array (
  '<strong>Space</strong> Modules' => '',
  'Activated' => 'تم التفعيل',
  'Are you sure? *ALL* module data for this space will be deleted!' => '',
  'Configure' => 'إعدادات',
  'Currently there are no modules available for this space!' => '',
  'Disable' => 'إلغاء التفعيل',
  'Enable' => 'تفعيل',
  'Enhance this space with modules.' => '',
);
