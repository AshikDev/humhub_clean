<?php
return array (
  '<strong>Confirm</strong> image deleting' => '',
  'Cancel' => 'إلغاء',
  'Delete' => 'حذف',
  'Do you really want to delete your profile image?' => '',
);
