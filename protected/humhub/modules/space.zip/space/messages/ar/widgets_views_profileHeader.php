<?php
return array (
  '<strong>Something</strong> went wrong' => '',
  'Followers' => '',
  'Members' => 'الأعضاء',
  'Ok' => 'تمام',
  'Posts' => '',
);
