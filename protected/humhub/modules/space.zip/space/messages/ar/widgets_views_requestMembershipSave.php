<?php
return array (
  'Close' => 'اغلاق',
  'Request workspace membership' => '',
  'Your request was successfully submitted to the workspace administrators.' => '',
);
