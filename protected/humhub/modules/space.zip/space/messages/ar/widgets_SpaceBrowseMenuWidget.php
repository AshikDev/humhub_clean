<?php
return array (
  'My Space List' => '',
  'My space summary' => '',
  'Space directory' => '',
  'Spaces' => 'الباحات',
);
