<?php
return array (
  'Invites' => '',
  'New user by e-mail (comma separated)' => '',
  'User \'{username}\' is already a member of this space!' => '',
  'User \'{username}\' is already an applicant of this space!' => '',
  'User not found!' => 'لم يتم إيجاد العضو',
  '{email} is already registered!' => '{email} مسجل بالفعل!
',
  '{email} is not valid!' => '{email} غير صحيح!
',
);
