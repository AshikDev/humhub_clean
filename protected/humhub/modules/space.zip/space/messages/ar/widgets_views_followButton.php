<?php
return array (
  'Follow' => 'متابعة',
  'Unfollow' => 'إلغاء المتابعة',
);
