<?php
return array (
  'Change image' => '',
  'Current space image' => '',
);
