<?php
return array (
  '<b>This space is still empty!</b>' => '<b>Iste espacio encara ye vuido!</b>',
  '<b>This space is still empty!</b><br>Start by posting something here...' => '<b>Iste espacio encara ye vuido!</b><br>Empecipia publicando bella cosa aquí...',
  '<b>You are not member of this space and there is no public content, yet!</b>' => '<b>No yes miembro d\'iste espacio y no i hai conteniu encara!</b>',
);
