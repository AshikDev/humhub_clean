<?php
return array (
  'View Online' => 'Veyer en linia',
);
