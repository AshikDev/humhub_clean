<?php
return array (
  'Cancel' => 'Cancelar',
  'Please shortly introduce yourself, to become a approved member of this workspace.' => '',
  'Request workspace membership' => '',
  'Send' => '',
);
