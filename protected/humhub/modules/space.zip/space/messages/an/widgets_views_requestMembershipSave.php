<?php
return array (
  'Close' => 'Zavřít',
  'Request workspace membership' => '',
  'Your request was successfully submitted to the workspace administrators.' => '',
);
