<?php
return array (
  '<strong>Confirm</strong> image deleting' => '',
  'Cancel' => 'Cancelar',
  'Delete' => 'Eliminar',
  'Do you really want to delete your profile image?' => '',
);
