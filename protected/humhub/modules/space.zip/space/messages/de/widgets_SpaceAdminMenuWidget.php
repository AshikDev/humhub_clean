<?php
return array (
  '<i class="fa fa-cog"></i>' => '<i class="fa fa-cog"></i>',
  'Cancel Membership' => 'Mitgliedschaft beenden',
  'Don\'t receive notifications for new content' => 'Keine Benachrichtigungen über neue Inhalte mehr empfangen',
  'Hide posts on dashboard' => 'Beiträge in der Übersicht ausblenden',
  'Members' => 'Mitglieder',
  'Modules' => 'Module',
  'Receive Notifications for new content' => 'Benachrichtigungen über neue Inhalte empfangen',
  'Security' => 'Sicherheit',
  'Show posts on dashboard' => 'Beiträge in der Übersicht anzeigen',
  'This option will hide new content from this space at your dashboard' => 'Diese Option blendet neue Inhalte aus diesem Space in Deiner Übersicht aus.',
  'This option will show new content from this space at your dashboard' => 'Diese Option zeigt neue Inhalte aus diesem Space in Deiner Übersicht an.',
);
