<?php
return array (
  'Your password' => 'Dein Passwort',
);
