<?php
return array (
  '<strong>New</strong> member request' => '<strong>Neuer</strong> Mitgliedsantrag',
  '<strong>Space</strong> members' => '<strong>Space</strong>-Mitglieder',
  'Show all' => 'Alle anzeigen',
);
