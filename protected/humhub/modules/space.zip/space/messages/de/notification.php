<?php
return array (
  'You were added to Space {spaceName}' => 'Du wurdest zum Space {spaceName} hinzugefügt',
  '{displayName} accepted your invite for the space {spaceName}' => '{displayName} hat deine Einladung in den Space {spaceName} akzeptiert',
  '{displayName} approved your membership for the space {spaceName}' => '{displayName} hat deine Mitgliedschaft im Space {spaceName} bestätigt',
  '{displayName} changed your role to {roleName} in the space {spaceName}.' => '{displayName} hat im Space {spaceName} Deine Rolle auf {roleName} geändert.
',
  '{displayName} declined your invite for the space {spaceName}' => '{displayName} hat deine Einladung in den Space {spaceName} abgelehnt',
  '{displayName} declined your membership request for the space {spaceName}' => '{displayName} hat deine Mitgliedschafts-Anfrage für den Space {spaceName} abgelehnt',
  '{displayName} invited you to the space {spaceName}' => '{displayName} hat dich in den Space {spaceName} eingeladen',
  '{displayName} requests membership for the space {spaceName}' => '{displayName} bittet um Mitgliedschaft im Space {spaceName}',
);
