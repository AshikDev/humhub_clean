<?php
return array (
  'Space has been archived' => 'Der Space wurde archivert',
  'Space has been unarchived' => 'Die Archivierung des Space wurde zurückgenommen',
  'Space member joined' => 'Space Mitglied beigetreten',
  'Space member left' => 'Space Mitglied ausgetreten',
  'Whenever a member leaves one of your spaces.' => 'Wenn ein Mitglied aus einem deiner Spaces austritt.',
  'Whenever a new member joined one of your spaces.' => 'Wenn ein neues Mitglied einem deiner Spaces beitritt.',
  'Whenever a space is archived.' => 'Immer, wenn ein Space archiviert wurde.',
  'Whenever a space is unarchived.' => 'Immer, wenn die Archivierung eines Space zurückgenommen wurde.',
);
