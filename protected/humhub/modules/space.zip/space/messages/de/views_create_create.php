<?php
return array (
  '<strong>Create</strong> new space' => 'Neuen Space <strong>erstellen</strong>',
  'Advanced access settings' => 'Erweiterte Zugriffseinstellungen',
  'Next' => 'Weiter',
  'Space name' => 'Space Name',
  'space description' => 'Space-Beschreibung',
);
