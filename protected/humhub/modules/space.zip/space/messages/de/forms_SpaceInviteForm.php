<?php
return array (
  'Invites' => 'Einladungen',
  'New user by e-mail (comma separated)' => 'Neue Benutzer per E-Mail (getrennt durch Kommas)',
  'User \'{username}\' is already a member of this space!' => 'Der Benutzer \'{username}\' ist bereits Mitglied des Spaces!',
  'User \'{username}\' is already an applicant of this space!' => 'Der Benutzer \'{username}\' hat bereits die Mitgliedschaft in diesem Space beantragt!',
  'User not found!' => 'Benutzer nicht gefunden!',
  '{email} is already registered!' => '{email} ist bereits registriert!',
  '{email} is not valid!' => '{email} ist ungültig!',
);
