<?php
return array (
  '<strong>Request</strong> space membership' => 'Space-Mitgliedschaft <strong>beantragen</strong> ',
  'Close' => 'Schließen',
  'Please shortly introduce yourself, to become an approved member of this space.' => 'Um bestätigtes Mitglied dieses Spaces zu werden, stelle dich bitte kurz vor.',
);
