<?php
return array (
  'Receive Notifications of Space Membership events.' => 'Benachrichtigungen über Space-Mitgliedschaftsereignisse erhalten',
  'Space Membership' => 'Space Mitgliedschaft',
);
