<?php
return array (
  'Members' => 'Mitglieder',
  'Owner' => 'Besitzer',
  'Pending Approvals' => 'Ausstehende Genehmigungen',
  'Pending Invites' => 'Ausstehende Einladungen',
);
