<?php
return array (
  'Created At' => 'Erstellt am',
  'Created By' => 'Erstellt von',
  'Last Visit' => 'Letzter Besuch',
  'Originator User ID' => 'Ersteller User ID',
  'Request Message' => 'Anfragenachricht',
  'Status' => 'Status',
  'Updated At' => 'Aktualisiert am',
  'Updated By' => 'Aktualisiert von',
);
