<?php
return array (
  '<strong>Something</strong> went wrong' => '<strong>Irgendwas</strong> ging schief',
  'Followers' => 'Follower',
  'Members' => 'Mitglieder',
  'Ok' => 'Ok',
  'Posts' => 'Beiträge',
);
