<?php
return array (
  'Friendship' => 'Freundschaft',
  'Receive Notifications for Friendship Request and Approval events.' => 'Benachrichtigungen für Freundschaftsanfragen und Genehmigungen erhalten.',
);
