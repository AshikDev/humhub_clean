<?php
return array (
  'This space is archived' => 'Dieser Space ist archiviert',
  'You are a member of this space' => 'Du bist Mitglied dieses Space',
  'You are following this space' => 'Du folgst diesem Space',
);
