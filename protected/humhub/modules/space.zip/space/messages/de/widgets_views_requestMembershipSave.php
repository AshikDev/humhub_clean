<?php
return array (
  'Close' => 'Schließen',
  'Request workspace membership' => 'Space-Mitgliedschaft beantragen',
  'Your request was successfully submitted to the workspace administrators.' => 'Deine Anfrage wurde erfolgreich an die Space-Administratoren weitergeleitet.',
);
