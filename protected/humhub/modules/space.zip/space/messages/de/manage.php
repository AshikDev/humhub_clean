<?php
return array (
  'As owner of this space you can transfer this role to another administrator in space.' => 'Als Besitzer dieses Space kannst du diese Rolle an einen anderen Administrator im Space übertragen.',
  'Remove from space' => 'Vom Space entfernen',
  'Show all' => 'Alle anzeigen',
  'Space owner' => 'Space Besitzer',
  'The url contains illegal characters!' => 'Die URL beinhaltet nicht erlaubte Zeichen !',
  'Transfer ownership' => 'Besitzrechte übertragen',
  'e.g. example for {baseUrl}/s/example' => 'z. B. example für {baseUrl}/s/example',
  'the default start page of this space for members' => 'Die Standard-Startseite für Mitglieder dieses Space',
  'the default start page of this space for visitors' => 'Die Standard-Startseite für Gästes dieses Space',
);
