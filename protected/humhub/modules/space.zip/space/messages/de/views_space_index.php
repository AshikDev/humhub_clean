<?php
return array (
  '<b>This space is still empty!</b>' => '<b>Dieser Space ist noch leer!</b>',
  '<b>This space is still empty!</b><br>Start by posting something here...' => '<strong>Dieser Space ist noch leer!</strong><br />Mache den Anfang und schreibe etwas...',
  '<b>You are not member of this space and there is no public content, yet!</b>' => '<b>Du bist kein Mitglied dieses Space. Derzeit liegen keinen öffentlichen Inhalte vor!</b>',
);
