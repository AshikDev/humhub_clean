<?php
return array (
  'Send & decline' => 'Senden und Ablehnen',
);
