<?php
return array (
  'Follow' => '',
  'Unfollow' => '',
);
