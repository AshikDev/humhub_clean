<?php
return array (
  'Close' => 'Zavřít',
  'Request workspace membership' => 'Žádost o členství v prostoru',
  'Your request was successfully submitted to the workspace administrators.' => 'Váše žádost byla uspěšně předána správci prostoru.',
);
