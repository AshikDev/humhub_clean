<?php
return array (
  'Add Space' => 'Přidat prostor',
  'No spaces found for the given query' => 'Pro daný dotaz nebyly nalezeny žádné mezery',
  'Select {n,plural,=1{space} other{spaces}}' => 'Zvolit {n,plural,=1{space} other{spaces}}',
  'This field only allows a maximum of {n,plural,=1{# space} other{# spaces}}' => 'Toto pole povoluje maximálně {n,plural,=1{# space} other{# spaces}}
',
);
