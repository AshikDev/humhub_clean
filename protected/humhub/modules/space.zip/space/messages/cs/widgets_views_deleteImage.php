<?php
return array (
  '<strong>Confirm</strong> image deleting' => '<strong>Potvrďte</strong> smazání obrázku',
  'Cancel' => 'Zrušit',
  'Delete' => 'Smazat',
  'Do you really want to delete your profile image?' => 'Opravdu chcete smazat svůj profilový obrázek?',
);
