<?php
return array (
  'This space is archived' => 'Tento prostor archívován',
  'You are a member of this space' => 'Jste členem tohoto prostoru',
  'You are following this space' => 'Sledujete tento prostor',
);
