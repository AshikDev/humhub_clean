<?php
return array (
  '<b>This space is still empty!</b>' => '<b>Tento prostor je stále prázdný!</b>',
  '<b>This space is still empty!</b><br>Start by posting something here...' => '<b>Zatím zde nejsou žádné příspěvky.</b><br>Napište první...',
  '<b>You are not member of this space and there is no public content, yet!</b>' => '<B> Nejste členem tohoto prostoru a zatím zde není žádný veřejný obsah! </ B>',
);
