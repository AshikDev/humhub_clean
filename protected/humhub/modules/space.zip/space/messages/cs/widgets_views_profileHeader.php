<?php
return array (
  '<strong>Something</strong> went wrong' => '<strong>Něco</strong> se pokazilo',
  'Followers' => 'sleduje mě',
  'Members' => 'Členové',
  'Ok' => 'Ok',
  'Posts' => 'Příspěvky',
);
