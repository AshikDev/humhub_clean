<?php
return array (
  'Invites' => 'Pozvánky',
  'New user by e-mail (comma separated)' => 'Pozvání uživatele pomocí e-mailu (adresy oddělte čárkou)',
  'User \'{username}\' is already a member of this space!' => 'Uživatele \'{username}\' je již členem tohoto prostoru!',
  'User \'{username}\' is already an applicant of this space!' => 'Uživatel \'{username}\' je již žadatelem tohoto prostoru!',
  'User not found!' => 'Uživatel nebyl nalezen!',
  '{email} is already registered!' => 'E-mailová adresa {email} již v databázi existuje!',
  '{email} is not valid!' => 'E-mailová adresa {email} není platná!',
);
