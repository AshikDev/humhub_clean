<?php
return array (
  'As owner you cannot revoke your membership!' => 'Nemůžete si zrušit členství tomto prostoru, protože jste jeho vlastník!',
  'Could not request membership!' => 'Není možné požádat o členství!',
  'Sorry, you are not allowed to leave this space!' => 'Omlouváme se, nemáte dovoleno opustit tento prostor!',
  'There is no pending invite!' => 'Momentálně zde není žádná pozvánka čekající na přijetí!',
  'This action is only available for workspace members!' => 'Tato akce je možná pouze pro členy prostoru!',
  'This user is already a member of this space.' => 'Tento uživatel je již členem tohoto prostoru.',
  'This user is not a member of this space.' => 'Tento uživatel není členem tohoto prostoru.',
  'You are not allowed to join this space!' => 'Není možné se připojit k tomuto prostoru!',
);
