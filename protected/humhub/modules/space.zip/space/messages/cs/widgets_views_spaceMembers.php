<?php
return array (
  '<strong>New</strong> member request' => '<strong>Nová</strong> žádost o členství',
  '<strong>Space</strong> members' => '<strong>Členové</strong> prostoru',
  'Show all' => 'Zobrazit vše',
);
