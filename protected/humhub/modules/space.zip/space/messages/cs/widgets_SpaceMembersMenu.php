<?php
return array (
  'Members' => 'Členové',
  'Owner' => 'Vlastník',
  'Pending Approvals' => 'Čeká na schválení',
  'Pending Invites' => 'Čekající pozvánky',
);
