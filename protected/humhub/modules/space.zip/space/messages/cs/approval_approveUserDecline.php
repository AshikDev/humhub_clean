<?php
return array (
  'Send & decline' => 'Odmítnout',
);
