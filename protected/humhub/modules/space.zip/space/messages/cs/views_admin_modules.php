<?php
return array (
  '<strong>Space</strong> Modules' => '<strong>Moduly</strong> prostoru',
  'Activated' => 'Aktivováno',
  'Are you sure? *ALL* module data for this space will be deleted!' => 'Jste si opravdu jistí? *VŠECHNA* data modulu k tomuto prostoru budou smazána!',
  'Configure' => 'Nastavit',
  'Currently there are no modules available for this space!' => 'Momentálně zde nejsou žádné dostupné moduly pro tento prostor!',
  'Disable' => 'Zakázat',
  'Enable' => 'Povolit',
  'Enhance this space with modules.' => 'Zde můžete rozšířit tento prostor moduly.',
);
