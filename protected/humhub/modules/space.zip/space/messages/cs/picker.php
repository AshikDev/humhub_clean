<?php
return array (
  'Add {n,plural,=1{space} other{spaces}}' => 'Přidat {n,plural,=1{space} další{spaces}}',
);
