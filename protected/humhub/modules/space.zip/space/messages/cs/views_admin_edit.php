<?php
return array (
  'Archive' => 'Archivovat',
  'Choose if new content should be public or private by default' => 'Zvolte, zda má být nový obsah ve výchozím nastavení veřejný nebo soukromý',
  'Choose the kind of membership you want to provide for this workspace.' => 'Vyberte, jak se lze stát členem prostoru.',
  'Choose the security level for this workspace to define the visibleness.' => 'Vyberte, jakou má mít prostor viditelnost.',
  'Delete' => 'Smazat',
  'Save' => 'Uložit',
  'Unarchive' => 'Obnovit z archívu',
);
