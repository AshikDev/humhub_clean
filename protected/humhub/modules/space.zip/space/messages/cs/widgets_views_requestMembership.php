<?php
return array (
  'Cancel' => 'Zrušit',
  'Please shortly introduce yourself, to become a approved member of this workspace.' => 'Stručně se prosím představte, aby bylo možné schválit vaše členství v tomto prostoru.',
  'Request workspace membership' => 'Žádost o členství v prostoru',
  'Send' => 'Odeslat',
);
