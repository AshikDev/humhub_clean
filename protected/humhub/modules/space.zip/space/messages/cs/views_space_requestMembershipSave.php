<?php
return array (
  '<strong>Request</strong> space membership' => '<strong>Žádost</strong> o členství v prostoru',
  'Close' => 'Zavřít',
  'Your request was successfully submitted to the space administrators.' => 'Váše žádost byla uspěšně předána správci prostoru.',
);
