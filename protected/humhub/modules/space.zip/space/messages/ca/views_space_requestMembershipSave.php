<?php
return array (
  '<strong>Request</strong> space membership' => '',
  'Close' => 'Tanca',
  'Your request was successfully submitted to the space administrators.' => '',
);
