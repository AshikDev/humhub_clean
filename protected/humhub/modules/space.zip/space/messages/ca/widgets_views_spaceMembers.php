<?php
return array (
  '<strong>New</strong> member request' => '<strong>Nova</strong> sol·licitud d\'unió',
  '<strong>Space</strong> members' => '<strong>Membres</strong> de l\'espai',
  'Show all' => 'Mostra totes',
);
