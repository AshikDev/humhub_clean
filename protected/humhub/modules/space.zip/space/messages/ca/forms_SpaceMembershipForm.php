<?php
return array (
  'Application message' => 'Missatge d\'invitació',
);
