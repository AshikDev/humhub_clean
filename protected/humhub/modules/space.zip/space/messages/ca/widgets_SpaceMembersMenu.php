<?php
return array (
  'Members' => 'Membres',
  'Owner' => 'Propietari',
  'Pending Approvals' => '',
  'Pending Invites' => '',
);
