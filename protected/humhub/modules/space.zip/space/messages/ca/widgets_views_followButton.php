<?php
return array (
  'Follow' => 'Segueix',
  'Unfollow' => 'No segueixis',
);
