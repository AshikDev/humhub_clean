<?php
return array (
  'Send & decline' => 'Envia i rebutja',
);
