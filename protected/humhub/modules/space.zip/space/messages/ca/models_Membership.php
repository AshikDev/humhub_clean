<?php
return array (
  'Created At' => 'Creat el',
  'Created By' => 'Creat per',
  'Last Visit' => '',
  'Originator User ID' => '',
  'Request Message' => '',
  'Status' => 'Estat',
  'Updated At' => 'Actualitzat el',
  'Updated By' => '',
);
