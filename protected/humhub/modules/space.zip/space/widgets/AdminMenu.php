<?php

namespace humhub\modules\space\widgets;

/**
 * Deprecated Admin Menu Widget 
 * 
 * Use humhub\module\space\modules\manage\widget\Menu instead!
 * This is only a stub to avoid potential module errors!
 * 
 * @author Luke
 * @since 0.5
 * @deprecated since version 0.21
 */
class AdminMenu extends \humhub\widgets\BaseMenu
{
    
}

?>
